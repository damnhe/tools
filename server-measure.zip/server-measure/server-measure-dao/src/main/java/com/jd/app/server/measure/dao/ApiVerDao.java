package com.jd.app.server.measure.dao;

import java.util.List;

import com.jd.app.server.measure.domain.ApiVerInfo;

public interface ApiVerDao {

	public ApiVerInfo selectVer();

	public ApiVerInfo selectToolVer();

	public int insertOrUpdate(ApiVerInfo info);

	public List<ApiVerInfo> selectApiVerList();

	public ApiVerInfo selectApiVerInfo(String name);

}
