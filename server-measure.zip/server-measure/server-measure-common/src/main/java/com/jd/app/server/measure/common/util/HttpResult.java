package com.jd.app.server.measure.common.util;

import org.apache.http.HttpResponse;

public class HttpResult {
    private HttpResponse response;
    private String content;
    private int statusCode;

    public int getStatusCode() {
        return statusCode;
    }

    public HttpResponse getResponse() {
        return response;
    }

    public void setResponse(HttpResponse response) {
        this.response = response;
        statusCode = response.getStatusLine().getStatusCode();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("status_line: ");
        sb.append(response.getStatusLine());
        sb.append(", content: ");
        sb.append(content);
        return sb.toString();
    }
}
