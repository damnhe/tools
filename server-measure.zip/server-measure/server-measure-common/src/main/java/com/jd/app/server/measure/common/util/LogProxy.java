package com.jd.app.server.measure.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LogProxy {
	private static final int LOG_DEBUG = 0;
	private static final int LOG_INFO = LOG_DEBUG + 1;
	private static final int LOG_WARN = LOG_INFO + 1;
	private static final int LOG_ERROR = LOG_WARN + 1;
	private static final Logger logger = LoggerFactory.getLogger("file_logger");
	
	public static void warn(String msg) {
		log(LOG_WARN, msg);
	}
	public static void error(String msg) {
		log(LOG_ERROR, msg);
	}
	public static void debug(String msg) {
		log(LOG_DEBUG, msg);
	}
	public static void stat(String msg) {
		log(LOG_INFO, msg);
	}
	
	// support
	protected static void log(int type, String msg) {
		switch (type) {
		case LOG_INFO:
			logger.info(msg);
			return;
		case LOG_WARN:
			logger.warn(msg);
			return;
		case LOG_ERROR:
			logger.error(msg);
			return;
		}
		logger.debug(msg);
	}
	
	private LogProxy() {
	}
}
