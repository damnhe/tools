package com.jd.app.server.measure.common.util;

import java.security.MessageDigest;

public class EncryptUtil {

	public static void main(String[] args) {
		EncryptUtil a = EncryptUtil.getInstance();
		for (int i = 0; i < 20; i++) {
			long t1 = System.currentTimeMillis();
			System.out.println(a.encrypt32BString(
					"..." + "abc" + i + "...."));
			long t2 = System.currentTimeMillis();
			System.out.println(t2 - t1);
		}
	}

	private static final Object syncObj = new Object();

	private static EncryptUtil instance = null;

	public static EncryptUtil getInstance() {
		synchronized (syncObj) {
			if (instance == null) {
				instance = new EncryptUtil();
			}
		}
		return instance;
	}

	private EncryptUtil() {
	}

	private final char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7',
			'8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	private String byteToHexString(byte[] tmp) {
		String s;
		char str[] = new char[16 * 2];
		int k = 0;
		for (int i = 0; i < 16; i++) {
			byte byte0 = tmp[i];
			str[k++] = hexDigits[byte0 >>> 4 & 0xf];
			str[k++] = hexDigits[byte0 & 0xf];
		}
		s = new String(str);
		return s;
	}

	public final String encrypt32BString(String s) {
		return encrypt32BString(s, "MD5");
	}

	public final String encrypt32BString(String s, String type) {
		String result = "";
		if (s.isEmpty()) {
			return result;
		}
		try {
			MessageDigest md = MessageDigest.getInstance(type);
			md.update(s.toString().getBytes("UTF-8"));
			byte[] res = md.digest();
			result = byteToHexString(res);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
