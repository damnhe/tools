package com.jd.app.server.measure.common.util;

import java.util.ArrayList;
import java.util.List;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public final class UmpUtils {

	public final static String PREFIX = "measure.v1.";

	public static CallerInfo reg(String key) {
		CallerInfo info = null;
		try {
			info = Profiler.registerInfo(key, true, true);
		} catch (Exception e) {
			LogProxy.error(e.toString());
		}
		return info;
	}

	public static List<CallerInfo> reg(List<String> keys) {
		if (keys == null || keys.isEmpty())
			return null;
		List<CallerInfo> ret = new ArrayList<CallerInfo>();
		for (String k : keys) {
			CallerInfo info = reg(k);
			if (info == null)
				continue;
			ret.add(info);
		}
		return ret;
	}

	public static void regEnd(CallerInfo info) {
		if (info == null)
			return;
		try {
			Profiler.registerInfoEnd(info);
		} catch (Exception e) {
			LogProxy.error(e.toString());
		}
	}

	public static void regEnd(List<CallerInfo> infos) {
		if (infos == null || infos.isEmpty())
			return;
		for (CallerInfo i : infos) {
			regEnd(i);
		}
	}

	public static void funcError(CallerInfo info) {
		if (info == null)
			return;
		try {
			Profiler.functionError(info);
		} catch (Exception e) {
			LogProxy.error(e.toString());
		}
	}

	public static void funcError(List<CallerInfo> infos) {
		if (infos == null || infos.isEmpty())
			return;
		for (CallerInfo i : infos) {
			funcError(i);
		}
	}
}
