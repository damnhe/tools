package com.jd.app.server.measure.common.util;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.FileEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class HttpUtil {

	public static HttpResult doPost(String url, Map<String, String> params)
			throws ClientProtocolException, IOException {
		HttpResult result = new HttpResult();
		HttpClient httpclient = HttpClientBuilder.create().build();
		String content = null;
		HttpPost httpPost = new HttpPost(url);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null) {
			for (Entry<String, String> pair : params.entrySet()) {
				nvps.add(new BasicNameValuePair(pair.getKey(), pair.getValue()));
			}
		}
		httpPost.setEntity(new UrlEncodedFormEntity(nvps, Consts.UTF_8.name()));
		HttpResponse response = httpclient.execute(httpPost);
		try {
			HttpEntity entity = response.getEntity();
			content = EntityUtils.toString(entity);
			EntityUtils.consume(entity);
			result.setResponse(response);
			result.setContent(content);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			httpPost.releaseConnection();
		}
		return result;
	}

	public static HttpResult doGet(String url) throws ClientProtocolException,
			IOException, Exception {
		HttpResult result = new HttpResult();
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response = httpclient.execute(httpGet);
		result.setResponse(response);
		try {
			HttpEntity entity = response.getEntity();
			String content = EntityUtils.toString(entity);
			result.setContent(content);
			EntityUtils.consume(entity);
		} catch (Exception e) {
			throw e;
		} finally {
			httpGet.releaseConnection();
		}

		return result;
	}

	public static int doPostFile(String url, Map<String, String> params, File f) {
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpPut httpPost = new HttpPut(url);
		try {
			FileEntity requestEntity = new FileEntity(f);

			if (params != null) {
				for (Entry<String, String> pair : params.entrySet()) {
					httpPost.addHeader(pair.getKey(), pair.getValue());
				}
			}
			httpPost.setEntity(requestEntity);
			httpPost.removeHeaders("Accept-Encoding");
			return httpclient.execute(httpPost).getStatusLine().getStatusCode();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			httpPost.releaseConnection();
			// httpclient.getHttpConnectionManager().closeIdleConnections(1l);;
		}
		return 0;
	}
/*
	public static void main(String args[]) {
		try {
			HttpResult result = doGet("http://e.cn.miaozhen.com/r.gif?k=1013739&p=4-1sJ0&rt=2&ns=[M_ADIP]&ni=[M_IESID]&na=[M_MAC]&o=http://sale.jd.com/act/P2oMfuidjRr10wsE.html&erpad_source=erpad");
			int a = 0;
			int b = a + 1;
		} catch (Exception ex) {

		}
	}*/
}
