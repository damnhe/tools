package com.jd.app.server.measure.common;

import java.util.Properties;

public final class RTConstant {
	// Singleton
	private static class Holder {
		private final static RTConstant instance = new RTConstant();
	}

	private static RTConstant getInstance() {
		return Holder.instance;
	}

	public static String getProperty(String key) {
		return getInstance()._getProperty(key);
	}

	public static boolean isProduction() {
		return getInstance()._isProduction();
	}

	public static boolean isNotProduction() {
		return getInstance()._isNotProduction();
	}

	// Support
	protected String _getProperty(String key) {
		return ((props == null) ? "" : props.getProperty(key, ""));
	}

	protected boolean _isProduction() {
		return isProduction;
	}

	protected boolean _isNotProduction() {
		return !isProduction;
	}

	private Properties props = null;
	private boolean isProduction = true;

	private RTConstant() {
		try {
			props = new Properties();
			props.load(RTConstant.class.getClassLoader().getResourceAsStream(
					"constant.properties"));
			// isProduction =
			// StaticConsts.RT.PROFILE_PRODUCTION.equals(_getProperty("const_db_env"));
		} catch (Exception e) {
			// LogProxy.error(e.toString());
		}
	}
}
