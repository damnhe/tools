package com.jd.app.server.measure.domain;

public class ResultCode {
	public final static int SUCCESS = 0;
	public final static int USER_NOT_EXISTED_OR_WRONG_PWD = 101;
	public final static int URL_CAN_NOT_BE_NULL = 102;
	public static final int USER_NOT_LOGIN = 103;
	public static final int USER_IS_NOT_AUTHORIZATION = 104;

}
