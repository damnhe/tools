package com.jd.app.server.measure.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.app.server.measure.dao.ApiVerDao;
import com.jd.app.server.measure.domain.ApiVerInfo;
import com.jd.app.server.measure.service.ApiService;

public class ApiServiceImpl implements ApiService {
	@Autowired
	private ApiVerDao apiVerDao = null;

	public ApiVerInfo getAPIVer(String v, String t) {
		return apiVerDao.selectVer();
	}

	
}
