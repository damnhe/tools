package com.jd.app.server.measure.service;

import com.jd.app.server.measure.domain.ApiVerInfo;

public interface ApiService {
	public ApiVerInfo getAPIVer(String v, String t);
}
