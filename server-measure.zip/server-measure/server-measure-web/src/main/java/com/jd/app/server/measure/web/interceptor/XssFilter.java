package com.jd.app.server.measure.web.interceptor;

import java.io.IOException;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;

public class XssFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(HttpServletRequest request,
			HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		request = new Request((HttpServletRequest) request);

		chain.doFilter(request, response);
	}

	// private Codec javaScrpitCodec = new JavaScriptCodec();
	// private final static char[] IMMUNE_JAVASCRIPT = { ',', '.', '_' };

	public String filterDangerString(String value) {
		if (value == null) {
			return null;
		}
		// value = ESAPI.encoder().encodeForJavaScript(value);
		// value = ESAPI.encoder().encodeForSQL(mysqlCodec, value);
		// value = javaScrpitCodec.encode(IMMUNE_JAVASCRIPT, value);
		value = value.replaceAll("<", "＜").replaceAll(">", "＞");
		value = value.replaceAll("\\(", "（").replaceAll("\\)", "）");
		value = value.replaceAll("'", "＇");
		value = value.replaceAll("\"", "＂");
		value = value.replaceAll("\"", "＂");
		value = Pattern.compile("(eval|javascript|script|function)", Pattern.CASE_INSENSITIVE)
				.matcher(value).replaceAll("");
		return value;
	}

	public static String toSBC(String input) {
		char c[] = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == ' ') {
				c[i] = '\u3000';
			} else if (c[i] < '\177') {
				c[i] = (char) (c[i] + 65248);

			}
		}
		return new String(c);
	}

	class Request extends HttpServletRequestWrapper {
		public Request(HttpServletRequest request) {
			super(request);
		}

		@Override
		public String getParameter(String name) {
			// 返回值之前 先进行过滤
			return filterDangerString(super.getParameter(name));
		}

		@Override
		public String[] getParameterValues(String name) {
			// 返回值之前 先进行过滤
			String[] values = super.getParameterValues(name);
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					values[i] = filterDangerString(values[i]);
				}
			}
			return values;
		}
	}

}