package com.jd.app.server.measure.web;

import java.io.IOException;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.jd.app.server.measure.common.util.DesUtils;
import com.jd.app.server.measure.common.util.JsonUtil;
import com.jd.app.server.measure.domain.ResultEntity;

public abstract class BaseAction {

	protected static final Logger logger = LoggerFactory
			.getLogger("file_logger");

	@ExceptionHandler(Exception.class)
	public void exceptionHandler(Exception ex, HttpServletResponse response,
			HttpServletRequest request) throws IOException {
		String url = request.getRequestURL().toString();
		logger.error(url);
		logger.error(ex.getMessage(), ex);
		ResultEntity re = new ResultEntity();
/*		if (ex.getClass() == IllegalStateException.class
				|| ex.getClass() == TypeMismatchException.class
				|| ex.getClass() == MissingServletRequestParameterException.class) {
			re.setRc(-1);
			// re.setRv(ex.getMessage());
		} else if (ex.getClass().getName().contains("org.springframework.dao")
				|| ex.getClass().getName().contains("org.mybatis.spring")) {
			re.setRc(-1);
			// /re.setRv("DAO Error");
		} else {
			re.setRc(-1);
		}*/
		re.setRc(-1);
		response.getWriter().write(JsonUtil.toJson(re));
		response.getWriter().flush();
		response.getWriter().close();
	}

	public String getUUID() {
		return java.util.UUID.randomUUID().toString();
	}

	public void setLoginCookie(HttpServletResponse response, String value,
			String remeber) {
		try {
			DesUtils desUtils = new DesUtils("...w23232...");
			value = desUtils.encrypt(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Cookie cookie = new Cookie("mobile_fit", value);
		cookie.setPath("/");
		if (remeber != null) {
			cookie.setMaxAge(60 * 60 * 24 * 30);
		}
		response.addCookie(cookie);
	}

	public void setLoginCookieExpire(HttpServletResponse response) {
		Cookie cookie = new Cookie("mobile_fit", null);
		cookie.setPath("/");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
	}



	public String filterDangerString(String value) {
		if (value == null) {
			return null;
		}
		// value = ESAPI.encoder().encodeForJavaScript(value);
		// value = ESAPI.encoder().encodeForSQL(mysqlCodec, value);
		// value = javaScrpitCodec.encode(IMMUNE_JAVASCRIPT, value);
		value = value.replaceAll("<", "＜").replaceAll(">", "＞");
		value = value.replaceAll("\\(", "（").replaceAll("\\)", "）");
		value = value.replaceAll("'", "＇");
		value = value.replaceAll("\"", "＂");
		value = value.replaceAll("\"", "＂");
		value = Pattern
				.compile("(eval|javascript|script|function)",
						Pattern.CASE_INSENSITIVE).matcher(value).replaceAll("");
		return value;
	}
}
