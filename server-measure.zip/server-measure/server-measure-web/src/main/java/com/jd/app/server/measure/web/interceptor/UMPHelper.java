package com.jd.app.server.measure.web.interceptor;

import java.lang.reflect.Method;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

import com.jd.app.server.measure.common.util.UmpUtils;
import com.jd.ump.profiler.CallerInfo;

@Aspect
public class UMPHelper {
	public UMPHelper() {

	}

	@Around("execution(* com.jd.app.server.measure.service.impl.*.*(..))")
	public Object aroundUMP(ProceedingJoinPoint joinPoint) throws Throwable {
		Signature signature = joinPoint.getSignature();
		MethodSignature methodSignature = (MethodSignature) signature;
		Method method = methodSignature.getMethod();
		String classname = joinPoint.getTarget().getClass().getName();
		String methodname = method.getName();
		String prefix = UmpUtils.PREFIX
				+ classname.substring("com.jd.app.server.measure.service.impl.".length());
		CallerInfo callerall = UmpUtils.reg(UmpUtils.PREFIX);
		CallerInfo callerInfo = UmpUtils.reg(prefix + "." + methodname);
		Object retVal = null;
		try {
			retVal = joinPoint.proceed();
		} catch (Throwable ex) {
			UmpUtils.funcError(callerInfo);
			throw ex;
		} finally {
			UmpUtils.regEnd(callerInfo);
			UmpUtils.regEnd(callerall);
		}
		return retVal;
	}
}
