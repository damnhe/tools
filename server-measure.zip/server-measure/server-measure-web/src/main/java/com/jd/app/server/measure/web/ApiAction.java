package com.jd.app.server.measure.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.app.server.measure.domain.ApiVerInfo;
import com.jd.app.server.measure.service.ApiService;

@Controller
@RequestMapping("/api")
public class ApiAction {

	@Autowired
	ApiService apiService = null;

	@RequestMapping(value = "/getApiVer.do", method = RequestMethod.GET)
	@ResponseBody
	public ApiVerInfo getAPIVer(HttpServletRequest request,
			HttpServletResponse response, String v, String t) {
		return apiService.getAPIVer(v, t);

	}

}