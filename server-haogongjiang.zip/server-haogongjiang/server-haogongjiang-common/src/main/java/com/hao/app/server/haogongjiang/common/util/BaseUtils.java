package com.hao.app.server.haogongjiang.common.util;

import java.util.Map;
import java.util.List;

public final class BaseUtils {
	// check data structure
	public static boolean listEmpty(List<?> l) {
		return (l == null || l.isEmpty());
	}

	public static boolean listNotEmpty(List<?> l) {
		return (l != null && l.size() > 0);
	}

	public static boolean strArrEmpty(String[] sa) {
		return (sa == null || sa.length <= 0);
	}

	public static boolean strArrNotEmpty(String[] sa) {
		return (sa != null && sa.length > 0);
	}

	public static boolean mapEmpty(Map<?, ?> m) {
		return (m == null || m.size() <= 0);
	}

	// check threshold
	public static boolean outBound(int val, int min, int max) {
		return (val < min || val > max);
	}

	// version conversion, return -1 if error
	private static final int VER_MAIN_SCALE = 100;

	public static int getVerInt(String ver) {
		try {
			String[] val = ver.split("\\.");
			if (val.length != 2)
				return -1;
			int main = Integer.parseInt(val[0]);
			if (main < 0)
				return -1;
			int sub = Integer.parseInt(val[1]);
			if (sub < 0)
				return -1;
			return (main * VER_MAIN_SCALE + sub);
		} catch (Exception e) {
			LogProxy.warn(e.toString());
		}
		return -1;
	}

	public static String getVerStr(int ver) {
		return StrExtFunc.concat(String.valueOf(ver / VER_MAIN_SCALE), ".",
				String.valueOf(ver % VER_MAIN_SCALE));
	}

	private BaseUtils() {
	}
}
