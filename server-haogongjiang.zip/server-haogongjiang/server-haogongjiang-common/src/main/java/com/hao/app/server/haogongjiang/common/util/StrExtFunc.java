package com.hao.app.server.haogongjiang.common.util;

import java.util.List;

public final class StrExtFunc {
	// test
	public static boolean isEmpty(String s) {
		return (s == null || s.isEmpty());
	}
	public static boolean isNotEmpty(String s) {
		return (s != null && s.length() > 0);
	}
	
	// join
	public static String join(String delimiter, String ...strArr) {
		if (BaseUtils.strArrEmpty(strArr))
			return "";
		if (strArr.length == 1)
			return strArr[0];
		StringBuilder sb = (new StringBuilder()).append(strArr[0]);
		for (int i=1; i<strArr.length; ++i) {
			sb.append(delimiter).append(strArr[i]);
		}
		return sb.toString();
	}
	public static String join(String delimiter, List<String> list) {
		if (BaseUtils.listEmpty(list))
			return "";
		if (list.size() == 1)
			return list.get(0);
		StringBuilder sb = (new StringBuilder()).append(list.get(0));
		for (int i=1; i<list.size(); ++i) {
			sb.append(delimiter).append(list.get(i));
		}
		return sb.toString();
	}
	
	// concat
	public static String concat(String ...strArr) {
		StringBuilder sb = new StringBuilder();
		for (String s : strArr) {
			sb.append(s);
		}
		return sb.toString();
	}
	public static String concat(List<String> list) {
		if (BaseUtils.listEmpty(list))
			return "";
		if (list.size() == 1)
			return list.get(0);
		StringBuilder sb = new StringBuilder();
		for (String i : list) {
			sb.append(i);
		}
		return sb.toString();
	}
	
	// path
	public static final String PATH_SEPERATOR = "/";
	public static String appendPath(String path, String comp) {
		return concat(path, PATH_SEPERATOR, comp);
	}
	public static String appendPath(String path, String comp1, String comp2) {
		return join(PATH_SEPERATOR, path, comp1, comp2);
	}
	
	// value parse
	public static int toInt(String s) {
		if (isEmpty(s))
			return Integer.MIN_VALUE;
		try {
			return Integer.parseInt(s);
		} catch (NumberFormatException e) {
			LogProxy.warn(e.toString());
		}
		return Integer.MIN_VALUE;
	}
	public static long toLong(String s) {
		if (isEmpty(s))
			return Long.MIN_VALUE;
		try {
			return Long.parseLong(s);
		} catch (NumberFormatException e) {
			LogProxy.warn(e.toString());
		}
		return Long.MIN_VALUE;
	}

	

	private StrExtFunc() {}
}
