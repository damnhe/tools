package com.hao.app.server.haogongjiang.common.util;

import java.io.StringWriter;
import java.text.SimpleDateFormat;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;



public class JsonUtil {

	private static ObjectMapper objectMapper = null;
	static {
		objectMapper = new ObjectMapper().configure(org.codehaus.jackson.JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
		SerializationConfig sc = objectMapper.getSerializationConfig();
		sc.withDateFormat(new SimpleDateFormat("yyyyMMddhhmmss"));
		sc.set(org.codehaus.jackson.map.SerializationConfig.Feature.SORT_PROPERTIES_ALPHABETICALLY,
				true);
		DeserializationConfig dc = objectMapper.getDeserializationConfig();
		dc.set(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.setSerializationConfig(sc);
	}

	public static String toJson(Object object) {
		try {
			StringWriter sw = new StringWriter();
			JsonGenerator gen = new JsonFactory().createJsonGenerator(sw);
			objectMapper.writeValue(gen, object);
			gen.close();
			return sw.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "{}";
	}

	public static <E> E fromJson(String json, Class<E> clazzString) {
		E t = null;
		try {
			t = objectMapper.readValue(json, clazzString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}

	public static void main(String[] args) {
		String json = "{username:\"abc\",password:\"12345678\"}";
		A a = fromJson(json,A.class);
		System.out.println(a.username);
		System.out.println(a.password);
	}

	public final static class A {
		private String username;
		private String password;

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
	}
}
