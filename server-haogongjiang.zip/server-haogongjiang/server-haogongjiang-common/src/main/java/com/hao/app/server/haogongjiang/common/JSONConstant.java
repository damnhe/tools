package com.hao.app.server.haogongjiang.common;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public final class JSONConstant {
	// Singleton
	private static class Holder {
		static final ObjectMapper om = new ObjectMapper();
	}

	public static ObjectMapper getMapper() {
		return Holder.om;
	}

	public static String writeValueAsString(Object value)
			throws JsonGenerationException, JsonMappingException, IOException {
		return getMapper().writeValueAsString(value);
	}

	// Common
	public static final String KEY_VER = "ver";
	public static final String KEY_ERR = "err";
	public static final String KEY_ERR_MSG = "err_msg";
	public static final String KEY_DATA = "data";
	public static final String KEY_DATA_CNT = "data_cnt";

	public static final String KEY_GENDER = "gender";
	public static final String KEY_ADULT = "adult";

	public static final String KEY_SKUID = "skuid";
	public static final String KEY_UUID = "uuid";
	public static final String KEY_NAME = "name";
	public static final String KEY_URL = "url";

	public static final String KEY_TYPE = "type";
	public static final String KEY_VER_MIN = "vmin";
	public static final String KEY_STATUS = "st";
	public static final String KEY_CREATE_TIME = "ctime";
	public static final String KEY_UPDATE_TIME = "utime";
	public static final String KEY_ICON = "icon";
	public static final String KEY_SORT = "sort";

	public static final String KEY_SHELF = "shelf";

	public static final String KEY_MSG = "msg";
	public static final String KEY_INFO = "info";

	public static final String KEY_BRAND = "brand";
	public static final String KEY_BIG_LOGO = "big_logo";
	public static final String KEY_SMALL_LOGO = "small_logo";
	public static final String KEY_ITEM_CNT = "item_cnt";
	public static final String KEY_LOOK_CNT = "look_cnt";
	public static final String KEY_ITEM_CATE = "item_cate";

	public static final String KEY_CNT = "cnt";
	public static final String KEY_PRICE_M = "m_price";
	public static final String KEY_PRICE_JD = "jd_price";

	// Error codes
	public static final int ERR_NONE = 0;
	public static final int ERR_FAILED = 1;
	public static final int ERR_UPGRADE = 2;

	public static final int ERR_EXCEPTION = ERR_NONE - 1;

	public static final int ERR_INVALID_PARAM = ERR_FAILED + 100;
	public static final String ERR_MSG_INVALID_PARAM = "invalid param: ";

	public static final int ERR_INVALID_ENCTYPE = ERR_INVALID_PARAM + 1;
	public static final String ERR_MSG_INVALID_ENCTYPE = "enctype must be multipart/form-data";
	public static final int ERR_UNSUPPORTED_TYPE = ERR_INVALID_ENCTYPE + 1;
	public static final String ERR_MSG_UNSUPPORTED_TYPE = "unsupported object type";
	public static final int ERR_INVALID_FILE_EXT = ERR_UNSUPPORTED_TYPE + 1;
	public static final String ERR_MSG_INVALID_FILE_EXT = "invalid file extensions, need *";
	public static final int ERR_FILE_FAILED = ERR_INVALID_FILE_EXT + 1;
	public static final String ERR_MSG_FILE_FAILED = "failed to write file";

	private JSONConstant() {
	}
}
