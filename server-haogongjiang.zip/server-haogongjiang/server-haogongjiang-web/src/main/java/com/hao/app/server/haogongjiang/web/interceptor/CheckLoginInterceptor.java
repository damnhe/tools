package com.hao.app.server.haogongjiang.web.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
//import com.hao.app.server.haogongjiang.domain.ResultCode;
//import com.hao.app.server.haogongjiang.domain.ResultEntity;

public class CheckLoginInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger("file_logger");

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		//String url = request.getRequestURL().toString();

//		if (!url.contains("login")) {
//			UserInfo ui = getUserInfo(request);
//			ResultEntity re = new ResultEntity();
//			if (ui == null) {
//				re.setRc(ResultCode.USER_NOT_LOGIN);
//				re.setRv("You are not login !");
//				response.getWriter().write(JsonUtil.toJson(re));
//				response.getWriter().flush();
//				response.getWriter().close();
//				return false;
//			}
//			if (ui.getType() != 0) {
//				re.setRc(ResultCode.USER_IS_NOT_AUTHORIZATION);
//				re.setRv("You are not authorized!");
//				response.getWriter().write(JsonUtil.toJson(re));
//				response.getWriter().flush();
//				response.getWriter().close();
//				return false;
//			}
//		}
		return super.preHandle(request, response, handler);
	}

}
