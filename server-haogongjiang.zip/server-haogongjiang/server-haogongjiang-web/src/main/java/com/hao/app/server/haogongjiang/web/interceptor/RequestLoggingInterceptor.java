package com.hao.app.server.haogongjiang.web.interceptor;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class RequestLoggingInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger("file_logger");


	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		String url = request.getRequestURL().toString();

		Map<String, String[]> map = request.getParameterMap();
		StringBuilder sb = new StringBuilder();
		sb.append(url);
		sb.append(" {");
		for (Entry<String, String[]> pair : map.entrySet()) {
			String key = pair.getKey();
			if (key.equalsIgnoreCase("pam") || key.equalsIgnoreCase("preview")
					|| key.equalsIgnoreCase("small_logo")
					|| key.equalsIgnoreCase("big_logo")) {
				continue;
			}
			sb.append(key);
			sb.append("=");
			String[] values = pair.getValue();
			for (String value : values) {
				sb.append(value);
				sb.append(",");
			}
		}
		sb.append("}");
		logger.info(sb.toString());
		return super.preHandle(request, response, handler);
	}

	public static String getIP() {
		Enumeration<NetworkInterface> allNetInterfaces = null;
		try {
			allNetInterfaces = NetworkInterface.getNetworkInterfaces();
		} catch (java.net.SocketException e) {
			e.printStackTrace();
		}
		InetAddress ip = null;
		if (allNetInterfaces != null) {
			while (allNetInterfaces.hasMoreElements()) {
				NetworkInterface netInterface = (NetworkInterface) allNetInterfaces
						.nextElement();
				Enumeration<InetAddress> addresses = netInterface
						.getInetAddresses();
				while (addresses.hasMoreElements()) {
					ip = (InetAddress) addresses.nextElement();
					if (ip != null && ip instanceof Inet4Address) {
						if (!ip.getHostAddress().equalsIgnoreCase("127.0.0.1")) {
							return ip.getHostAddress();
						}
					}
				}
			}
		}
		return "127.0.0.1";
	}
}
