package com.hao.app.server.haogongjiang.domain;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ResultEntity {

	private int rc;
	private Object rv;

	public int getRc() {
		return rc;
	}

	public void setRc(int rc) {
		this.rc = rc;
	}

	public Object getRv() {
		return rv;
	}

	public void setRv(Object rv) {
		this.rv = rv;
	}

}
