package com.hao.app.server.haogongjiang.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ApiVerInfo {
	private String name = "comp";
	private String curr_ver;
	private String min_ver;
	private String msg;
	private String info;
	private String download_url;
	private long update_time;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMin_ver() {
		return min_ver;
	}

	public void setMin_ver(String min_ver) {
		this.min_ver = min_ver;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getDownload_url() {
		return download_url;
	}

	public void setDownload_url(String download_url) {
		this.download_url = download_url;
	}

	public long getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(long update_time) {
		this.update_time = update_time;
	}

	public String getDate_string() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date date = new Date(this.update_time * 1000);
		return sdf.format(date);
	}

	public String getCurr_ver() {
		return curr_ver;
	}

	public void setCurr_ver(String curr_ver) {
		this.curr_ver = curr_ver;
	}
}
