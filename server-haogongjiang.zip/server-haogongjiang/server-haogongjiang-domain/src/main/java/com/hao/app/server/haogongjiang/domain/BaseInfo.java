package com.hao.app.server.haogongjiang.domain;

public class BaseInfo {
	protected String realUrl(String url) {
		if (url == null) {
			return null;
		}
		if (url.indexOf("storage.jd.com") > 0
				|| url.indexOf("192.168.150.52") > 0) {
			return url;
		}
		return RTConstant.getProperty("const_res_url_prefix") + url;
	}

}
