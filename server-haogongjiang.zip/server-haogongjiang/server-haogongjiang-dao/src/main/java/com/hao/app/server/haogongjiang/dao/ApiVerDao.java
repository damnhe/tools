package com.hao.app.server.haogongjiang.dao;

import java.util.List;

import com.hao.app.server.haogongjiang.domain.ApiVerInfo;

public interface ApiVerDao {

	public ApiVerInfo selectVer();

	public ApiVerInfo selectToolVer();

	public int insertOrUpdate(ApiVerInfo info);

	public List<ApiVerInfo> selectApiVerList();

	public ApiVerInfo selectApiVerInfo(String name);

}
