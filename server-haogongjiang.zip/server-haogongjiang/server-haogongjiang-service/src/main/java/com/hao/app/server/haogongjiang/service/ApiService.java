package com.hao.app.server.haogongjiang.service;

import com.hao.app.server.haogongjiang.domain.ApiVerInfo;

public interface ApiService {
	public ApiVerInfo getAPIVer(String v, String t);
	

	
	public boolean setVer(String name, String cur_ver, String min_ver,
			String msg, String info, String download_url);
}
