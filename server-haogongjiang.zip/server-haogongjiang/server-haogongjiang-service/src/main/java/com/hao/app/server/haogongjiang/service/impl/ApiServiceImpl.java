package com.hao.app.server.haogongjiang.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.hao.app.server.haogongjiang.dao.ApiVerDao;
import com.hao.app.server.haogongjiang.domain.ApiVerInfo;
import com.hao.app.server.haogongjiang.service.ApiService;

public class ApiServiceImpl implements ApiService {
	@Autowired
	private ApiVerDao apiVerDao = null;


	public ApiVerInfo getAPIVer(String v, String t) {
		return apiVerDao.selectVer();
	}

	@Override
	public boolean setVer(String name, String cur_ver, String min_ver,
			String msg, String info, String download_url) {
		ApiVerInfo ver = new ApiVerInfo();
		ver.setDownload_url(download_url);
		ver.setInfo(info);
		ver.setMsg(msg);
		ver.setName(name);
		ver.setMin_ver(min_ver);
		ver.setCurr_ver(cur_ver);
		return apiVerDao.insertOrUpdate(ver) > 0;
	}

}
