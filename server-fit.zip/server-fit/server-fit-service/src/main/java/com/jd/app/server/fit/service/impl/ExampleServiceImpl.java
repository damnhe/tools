package com.jd.app.server.fit.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.app.server.fit.dao.DeviceTypeDao;
import com.jd.app.server.fit.domain.DeviceType;
import com.jd.app.server.fit.service.ExampleService;


public class ExampleServiceImpl implements ExampleService {

	@Autowired
	private DeviceTypeDao deviceTypeDao = null;

	public List<DeviceType> getAllDeviceType() {
		return deviceTypeDao.getAllDeviceType();
	}

}
