package com.jd.app.server.fit.service;

import java.util.List;

import com.jd.app.server.fit.domain.DeviceType;

public interface ExampleService {

	public List<DeviceType> getAllDeviceType();
}
