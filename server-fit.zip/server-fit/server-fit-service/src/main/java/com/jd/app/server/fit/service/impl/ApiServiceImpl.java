package com.jd.app.server.fit.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.jd.app.server.fit.dao.APIVerDao;
import com.jd.app.server.fit.dao.table.DAORowAPIVer;
import com.jd.app.server.fit.service.ApiService;

public class ApiServiceImpl implements ApiService {
	@Autowired
	private APIVerDao apiVerDao = null;

	public DAORowAPIVer GetAPIVer(String v, String t) {
		return apiVerDao.selectVer();
	}
}
