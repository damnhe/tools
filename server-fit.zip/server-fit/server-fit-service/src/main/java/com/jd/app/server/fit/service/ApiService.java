package com.jd.app.server.fit.service;

import com.jd.app.server.fit.dao.table.DAORowAPIVer;

public interface ApiService {
	public DAORowAPIVer GetAPIVer(String v, String t);

}
