package com.jd.app.server.fit.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.app.server.fit.dao.table.DAORowAPIVer;
import com.jd.app.server.fit.service.ApiService;

@Controller
@RequestMapping("/api")
public class ApiAction {
	private static final Logger logger = LoggerFactory.getLogger("file_logger");

	@Autowired
	ApiService apiService = null;

	@RequestMapping(value = "/GetAPIVer.do", method = RequestMethod.GET)
	@ResponseBody
	public DAORowAPIVer GetAPIVer(HttpServletRequest request,
			HttpServletResponse response,String v,String t) {
		return apiService.GetAPIVer(v, t);

	}

}