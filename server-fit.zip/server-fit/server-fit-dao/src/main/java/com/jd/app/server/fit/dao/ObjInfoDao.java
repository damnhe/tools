package com.jd.app.server.fit.dao;

import java.util.List;

import com.jd.app.server.fit.dao.param.DAOParamSelectObjs;
import com.jd.app.server.fit.dao.table.DAORowBase;

public interface ObjInfoDao {

	public List<DAORowBase> selectObjs(DAOParamSelectObjs param);

}
