package com.jd.app.server.fit.dao;

import java.util.List;

import com.jd.app.server.fit.dao.param.DAOParamBrandCnt;
import com.jd.app.server.fit.dao.param.DAOParamSelectBrands;
import com.jd.app.server.fit.dao.table.DAORowBase;
import com.jd.app.server.fit.dao.table.DAORowBrandCnt;

public interface BrandDao {

	public List<DAORowBase> selectBrands(DAOParamSelectBrands brandInfo);

	public List<DAORowBrandCnt> selectBrandCnt(DAOParamBrandCnt brandInfo);
}
