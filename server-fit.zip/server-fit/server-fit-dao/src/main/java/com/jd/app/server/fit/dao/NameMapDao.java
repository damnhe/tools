package com.jd.app.server.fit.dao;

import java.util.List;

import com.jd.app.server.fit.dao.table.DAORowName;

public interface NameMapDao {

	List<DAORowName> selectNames();

}
