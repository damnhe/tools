package com.jd.app.server.fit.dao.param;

public class DAOParamUpgradeObjInfoVer {
	private String verOld;
	private String verNew;
	private String[] filter;
	private long upgradeTime;

	public String getVerOld() {
		return verOld;
	}
	public void setVerOld(String verOld) {
		this.verOld = verOld;
	}
	public String getVerNew() {
		return verNew;
	}
	public void setVerNew(String verNew) {
		this.verNew = verNew;
	}
	public String[] getFilter() {
		return filter;
	}
	public void setFilter(String[] filter) {
		this.filter = filter;
	}
	public long getUpgradeTime() {
		return upgradeTime;
	}
	public void setUpgradeTime(long upgradeTime) {
		this.upgradeTime = upgradeTime;
	}

}
