package com.jd.app.server.fit.dao.table;


public class DAORowObjList extends DAORowBase {
	private String objType;
	private String resVer;
	private String uuid;
	private String name;
	private String url;
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getResVer() {
		return resVer;
	}
	public void setResVer(String resVer) {
		this.resVer = resVer;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	
}
