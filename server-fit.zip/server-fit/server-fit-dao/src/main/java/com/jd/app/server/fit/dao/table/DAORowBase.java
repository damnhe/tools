package com.jd.app.server.fit.dao.table;

import com.jd.app.server.fit.common.RTConstant;

public abstract class DAORowBase {

	protected String realUrl(String url) {
		return RTConstant.getProperty("const_res_url_prefix") + url;
	}

	protected String realUrl(String url, String ver) {
		return null;
	}
}
