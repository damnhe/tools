package com.jd.app.server.fit.dao.param;

public class DAOParamDelObj extends DAOParamBase {
	private String uuid;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
}
