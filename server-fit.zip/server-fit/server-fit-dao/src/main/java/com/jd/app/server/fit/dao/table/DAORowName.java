package com.jd.app.server.fit.dao.table;

public final class DAORowName {
	private String nid;
	private String name;
	
	public String getNid() {
		return nid;
	}
	public void setNid(String nid) {
		this.nid = nid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
