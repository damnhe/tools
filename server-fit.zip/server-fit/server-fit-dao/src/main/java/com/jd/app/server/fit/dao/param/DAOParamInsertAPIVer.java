package com.jd.app.server.fit.dao.param;

public class DAOParamInsertAPIVer {

	private String name = "comp";
	private String ver;
	private String minVer;
	private String msg;
	private String info;
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVer() {
		return ver;
	}
	public void setVer(String ver) {
		this.ver = ver;
	}
	public String getMinVer() {
		return minVer;
	}
	public void setMinVer(String minVer) {
		this.minVer = minVer;
	}
	
}
