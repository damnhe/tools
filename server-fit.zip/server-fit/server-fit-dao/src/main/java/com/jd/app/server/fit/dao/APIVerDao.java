package com.jd.app.server.fit.dao;

import com.jd.app.server.fit.dao.param.DAOParamInsertAPIVer;
import com.jd.app.server.fit.dao.table.DAORowAPIVer;

public interface APIVerDao {
	
	public DAORowAPIVer selectVer();

	public int insertOrUpdate(DAOParamInsertAPIVer info);
}
