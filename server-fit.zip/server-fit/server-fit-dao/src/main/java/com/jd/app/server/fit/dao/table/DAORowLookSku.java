package com.jd.app.server.fit.dao.table;



public final class DAORowLookSku extends DAORowBase {
	private String uuid;
	private int skuid;
	private String url;
	private String name;
	
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public int getSkuid() {
		return skuid;
	}
	public void setSkuid(int skuid) {
		this.skuid = skuid;
	}
	
	public String getRealUrl(String ver) {
		return realUrl(url, ver);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
