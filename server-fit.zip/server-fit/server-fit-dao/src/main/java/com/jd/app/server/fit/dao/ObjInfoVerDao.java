package com.jd.app.server.fit.dao;

import com.jd.app.server.fit.dao.param.DAOParamDelObj;
import com.jd.app.server.fit.dao.param.DAOParamUpgradeObjInfoVer;

public interface ObjInfoVerDao {
	
	public int deleteRow(DAOParamDelObj param);

	public int insertUpgrade(DAOParamUpgradeObjInfoVer param);
}
