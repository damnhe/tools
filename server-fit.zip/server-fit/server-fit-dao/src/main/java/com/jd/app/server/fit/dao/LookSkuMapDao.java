package com.jd.app.server.fit.dao;

import java.util.List;

import com.jd.app.server.fit.dao.table.DAORowLookSku;

public interface LookSkuMapDao {

	public List<DAORowLookSku> selectSkus(List<String> param);

}
