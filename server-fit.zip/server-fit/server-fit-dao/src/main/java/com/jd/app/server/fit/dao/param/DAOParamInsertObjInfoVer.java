package com.jd.app.server.fit.dao.param;

public class DAOParamInsertObjInfoVer extends DAOParamBase implements Cloneable {
	private String uuid;
	private int minVer;
	private int maxVer;
	private int sort;
	private int status;
	
	public DAOParamInsertObjInfoVer(int ver, String objType, String uuid,
			int minVer, long updateTime) {
		//setVer(ver);
		setObjType(objType);
		setUuid(uuid);
		setMinVer(minVer);
	}
	
	public DAOParamInsertObjInfoVer(String objType, String uuid, int minVer,
			int maxVer, int sort, int status) {
		setObjType(objType);
		setUuid(uuid);
		setMinVer(minVer);
		setMaxVer(maxVer);
		setSort(sort);
		setStatus(status);
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public int getMinVer() {
		return minVer;
	}

	public void setMinVer(int minVer) {
		this.minVer = minVer;
	}

	public int getMaxVer() {
		return maxVer;
	}

	public void setMaxVer(int maxVer) {
		this.maxVer = maxVer;
	}

	public int getSort() {
		return sort;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
}
