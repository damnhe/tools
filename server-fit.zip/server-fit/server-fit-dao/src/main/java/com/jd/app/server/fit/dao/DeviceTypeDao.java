package com.jd.app.server.fit.dao;

import java.util.List;

import com.jd.app.server.fit.domain.DeviceType;

public interface DeviceTypeDao {
	public List<DeviceType> getAllDeviceType();
}
