package com.jd.app.server.fit.dao.param;

public class DAOParamBase {
	private String ver;
	private String objType;

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getVer() {
		return ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

}
